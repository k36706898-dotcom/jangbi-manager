장비매니저 v0.9.1 — 안드로이드 설치 준비 프로젝트
=================================================

[현재 파일의 상태]
- 실제 작동하는 HTML/JavaScript 소스, 앱 아이콘 PNG, Java Android WebView/SQLite 소스 포함
- 작업일지/검색/월별 거래처 정산/CSV/견적서/거래명세서/PDF 인쇄/주유일지/정비일지/JSON 전체 백업 기능 구현
- 이 ZIP은 설치형 APK가 아닙니다. Android Studio에서 직접 APK를 빌드해야 합니다.
- 이 환경에서는 Android SDK 및 Gradle이 없어 APK 컴파일과 실기기 시험은 수행하지 못했습니다.

[가장 쉬운 테스트 방법 — PC나 모바일 브라우저]
별도로 제공한 '장비매니저_v0.9.1_휴대폰_미리보기.html' 파일을 여세요.
브라우저에서도 기록, 견적서, 거래명세서를 시험할 수 있습니다.
단, 실제 업무자료를 넣기 전에는 반드시 JSON 백업을 먼저 만들어 테스트하세요.
브라우저 미리보기와 Android 앱 저장소는 서로 다른 저장소입니다.

[APK를 만드는 방법]
준비물: Windows / macOS / Linux 컴퓨터, Android Studio, 인터넷 연결(최초 SDK/Gradle 설치용)
1. 최신 호환 Android Studio 설치 후 SDK Manager에서 Android SDK 35 설치
2. Android Studio > File > Open > 이 폴더(장비매니저_v0.9.1_안드로이드_프로젝트) 선택
3. 프로젝트가 열리면 'Sync Project with Gradle Files' 실행
4. Gradle Wrapper JAR 파일이 없어서 Gradle 동기화가 되지 않는 경우:
   - Android Studio로 새 프로젝트(Empty Views Activity, Language Java, Min SDK 24)를 생성합니다.
   - 생성된 프로젝트의 app/src/main 폴더를 이 프로젝트의 app/src/main 폴더로 바꿉니다.
   - app/build.gradle의 namespace/applicationId을 com.ollim.jangbimanager로 설정하고
     compileSdk 35, minSdk 24, targetSdk 34를 맞춥니다.
   - Android Studio가 생성한 Gradle 래퍼는 그대로 두고 Sync를 실행합니다.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) 선택
6. 빌드가 성공하면 app/build/outputs/apk/debug/app-debug.apk 파일이 생성됩니다.
7. APK를 휴대폰으로 옮기고, 설치 허용 안내를 확인하여 설치합니다.
8. 홈 화면/앱 서랍의 '장비매니저' 안전모 아이콘을 눌러 실행합니다.

[기능 및 저장 경로]
- 작업일지: 달력 날짜 선택 -> 등록/수정/삭제
- 검색: 기간, 회사, 현장, 작업자, 배차자, 기종, 결제상태
- 정산: 월별 거래처 청구/입금/미수금 / 엑셀 호환 CSV 내보내기
- 거래명세서: 작업일지 또는 정산 화면에서 작성 / 추가 품목 및 부가세 수정
- 견적서: 품목, 수량, 단가, 현장, 유효기간 작성 / 저장 후 수정
- PDF 출력: 문서의 '인쇄/PDF' > 안드로이드 인쇄창에서 'PDF로 저장'
- 장비관리: 하단 장비관리 > 주유일지/정비일지, 장비별·월별 조회 및 수정·삭제
- 주유일지: 날짜, 장비, 연료, 주유량(L), 리터단가, 주유비, 주유소, 사용시간, 주행거리, 메모
- 정비일지: 날짜, 장비, 정비내용, 정비업체, 비용, 사용시간, 주행거리, 다음정비 예정일, 메모
- 월 장비관리 합계 및 CSV 내보내기 / 전체 JSON 백업 포함
- 전체 백업: 설정 > 전체 데이터 백업 (.json)
- 전체 복원: 설정 > 백업파일 복원 (기존 자료가 전부 교체됩니다)
- Android 앱 저장소: 외부 서버가 아닌 기기 내 SQLite(crane_manager.db)
- 인터넷 권한: 요청하지 않음. 주요 기능 오프라인 사용.

[주의]
- 최초 실행 시 환경설정에서 상호명, 대표자, 기종을 입력하세요.
- 장비는 기본값 '13t / KATO MR-130RF'로 준비되어 있고 필요 시 변경 가능합니다.
- 청구금액을 기반으로 명세서를 만들 때 기본 부가세는 '포함'입니다.
  공급가액/부가세 구분은 실제 계약 및 세금처리 조건에 따라 반드시 확인해야 합니다.
- 이 버전의 문서 인쇄/PDF는 시스템 인쇄 기능을 활용합니다.
- 실제 휴대폰 설치, 파일 선택 및 인쇄 동작은 빌드 뒤 현장 테스트가 필요합니다.

[개발/검증]
- JDK 17 / Android Gradle Plugin 8.5.2 / Gradle 8.7 / SDK 35를 목표로 구성
- tests/logic.test.js 에 오프라인 계산/검색/문서 관련 단위 테스트 포함
- 실행: node tests/logic.test.js
- 2026-11-19 제작. 실제 APK 생성 및 Android 실기기 검증 전 개발본입니다.

[아이콘 확정]
- 사용자가 선택한 안전모 모양(남색 배경, 노란 안전모)을 정식 앱 아이콘으로 사용합니다.
- Android 홈 화면 아이콘(mipmap 전 해상도) 및 앱 내부 상단 아이콘에 반영했습니다.

[v0.9.1 업그레이드]
- SQLite DB 버전 1 → 2 자동 업그레이드. 기존 작업일지와 문서 기록은 유지되고 장비관리 테이블만 추가됩니다.
- v0.8/v0.9 이전 JSON 백업도 복원 가능하며 장비관리 내역은 빈 목록으로 시작합니다.
- 현재 APK와 실제 휴대폰 설치 검증은 아직 수행하지 못했습니다.

[공식 앱 아이콘]
사용자가 직접 선택해 제공한 남색 배경·노란 안전모 아이콘을 적용했습니다.
원본: app/src/main/icon_reference.jpg / 앱용 아이콘: app/src/main/res/mipmap-*/ic_launcher.png


[2026-11-19 APK 자동 빌드 설정]
- GitHub Actions 수동 실행 빌드: .github/workflows/build-apk.yml
- 로컬 빌드 스크립트: APK_빌드.sh / APK_빌드.bat
- 사용법: APK_자동빌드_사용안내.txt
- 현재 환경에서 APK 직접 빌드 미완료 (Android SDK/Gradle 없음)
