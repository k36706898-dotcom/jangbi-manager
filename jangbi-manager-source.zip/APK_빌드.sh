#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo '장비매니저 v0.9.1 APK 빌드'
if ! command -v java >/dev/null 2>&1; then
  echo 'ERROR: JDK 17 이상이 필요합니다.' >&2; exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo 'ERROR: Gradle 8.7이 없습니다. GitHub Actions 자동 빌드 또는 Android Studio를 사용하세요.' >&2; exit 1
fi
if [ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  echo 'ERROR: Android SDK 경로(ANDROID_HOME)가 필요합니다.' >&2; exit 1
fi
if command -v node >/dev/null 2>&1; then
  node tests/logic.test.js
  node tests/ui-flow.test.js
fi
gradle --no-daemon :app:assembleDebug
echo "완료: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
