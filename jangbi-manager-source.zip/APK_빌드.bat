@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 장비매니저 v0.9.1 APK 빌드
where java >nul 2>nul
if errorlevel 1 (echo JDK 17 이상 설치가 필요합니다.&exit /b 1)
where gradle >nul 2>nul
if errorlevel 1 (echo Gradle 8.7이 없습니다. GitHub Actions 또는 Android Studio를 이용해 주세요.&exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo ANDROID_HOME 설정이 필요합니다.&exit /b 1)
where node >nul 2>nul
if not errorlevel 1 (
  node tests\logic.test.js || exit /b 1
  node tests\ui-flow.test.js || exit /b 1
)
call gradle --no-daemon :app:assembleDebug
if errorlevel 1 exit /b 1
echo 완료: %cd%\app\build\outputs\apk\debug\app-debug.apk
