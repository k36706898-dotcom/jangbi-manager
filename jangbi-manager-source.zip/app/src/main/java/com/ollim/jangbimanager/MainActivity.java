package com.ollim.jangbimanager;

import android.app.Activity;
import android.app.PrintManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 301;
    private static final int REQUEST_PICK_BACKUP = 302;
    private WebView webView;
    private Db db;
    private byte[] exportBytes;
    private ValueCallback<Uri[]> fileChooser;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new Db(this);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return request.getUrl() == null || !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooser != null) fileChooser.onReceiveValue(null);
                fileChooser = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(Intent.createChooser(intent,"백업 JSON 선택"),REQUEST_PICK_BACKUP);
                    return true;
                } catch (Exception e) {fileChooser = null; return false;}
            }
        });
        // The bridge is only exposed to the application's bundled offline assets.
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQUEST_PICK_BACKUP) {
            if (fileChooser != null) {
                fileChooser.onReceiveValue(resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
                fileChooser = null;
            }
        } else if(requestCode == REQUEST_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && exportBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("파일을 열 수 없습니다");
                    out.write(exportBytes);
                    Toast.makeText(this,"파일 저장 완료",Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {Toast.makeText(this,"저장 실패: "+ex.getMessage(),Toast.LENGTH_LONG).show();}
            }
            exportBytes = null;
        }
    }

    @Override public void onBackPressed() {
        // Exiting does not delete the SQLite database.
        super.onBackPressed();
    }

    private class Bridge {
        @JavascriptInterface public String listRecords() {return db.getRows("jobs").toString();}
        @JavascriptInterface public String listDocuments() {return db.getRows("documents").toString();}
        @JavascriptInterface public String listExpenses() {return db.getRows("expenses").toString();}
        @JavascriptInterface public String getSettings() {return db.settings();}
        @JavascriptInterface public boolean saveSettings(String json) {return db.saveSettings(json);}
        @JavascriptInterface public String upsertRecord(String json) {return db.upsert("jobs",json);}
        @JavascriptInterface public String upsertDocument(String json) {return db.upsert("documents",json);}
        @JavascriptInterface public String upsertExpense(String json) {return db.upsert("expenses",json);}
        @JavascriptInterface public boolean deleteRecord(int id) {return db.delete("jobs",id);}
        @JavascriptInterface public boolean deleteDocument(int id) {return db.delete("documents",id);}
        @JavascriptInterface public boolean deleteExpense(int id) {return db.delete("expenses",id);}
        @JavascriptInterface public boolean restoreBackup(String json) {return db.restore(json);}
        @JavascriptInterface public void exportFile(String filename,String mime,String content) {
            exportBytes = content.getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> {
                try {
                    Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    save.setType(mime.split(";")[0]);
                    save.addCategory(Intent.CATEGORY_OPENABLE);
                    save.putExtra(Intent.EXTRA_TITLE, filename.replaceAll("[/\\\\]","_"));
                    startActivityForResult(save,REQUEST_EXPORT);
                } catch (Exception ex) {Toast.makeText(MainActivity.this,"저장 창을 열 수 없습니다",Toast.LENGTH_LONG).show();}
            });
        }
        @JavascriptInterface public void printCurrentPage(String title) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    PrintManager manager=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    if(manager!=null)manager.print(title,webView.createPrintDocumentAdapter(title),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                }
            });
        }
    }

    private static class Db extends SQLiteOpenHelper {
        Db(Context c){super(c,"crane_manager.db",null,2);}
        @Override public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE jobs (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)");
            d.execSQL("CREATE TABLE documents (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)");
            d.execSQL("CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)");
            d.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, payload TEXT NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
            if(oldVersion<2)d.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)");
        }
        synchronized JSONArray getRows(String table){
            JSONArray result=new JSONArray();
            try(Cursor c=getReadableDatabase().rawQuery("SELECT payload FROM "+table+" ORDER BY id ASC",null)) {
                while(c.moveToNext())try{result.put(new JSONObject(c.getString(0)));}catch(Exception ignored){}
            }
            return result;
        }
        synchronized String settings(){
            try(Cursor c=getReadableDatabase().rawQuery("SELECT payload FROM settings WHERE k='main'",null)) {
                if(c.moveToFirst())return c.getString(0);
            }
            return "{}";
        }
        synchronized boolean saveSettings(String json){
            try {new JSONObject(json);ContentValues v=new ContentValues();v.put("k","main");v.put("payload",json);return getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)>=0;}
            catch(Exception ex){return false;}
        }
        synchronized String upsert(String table,String json){
            if(!"jobs".equals(table)&&!"documents".equals(table)&&!"expenses".equals(table))return "{}";
            SQLiteDatabase d=getWritableDatabase();
            try {
                JSONObject obj=new JSONObject(json);
                int id=obj.isNull("id")?0:obj.optInt("id",0);
                if(id>0){
                    try(Cursor c=d.rawQuery("SELECT id FROM "+table+" WHERE id=?",new String[]{String.valueOf(id)})){
                        if(!c.moveToFirst())return "{}";
                    }
                    ContentValues v=new ContentValues();v.put("payload",obj.toString());
                    if(d.update(table,v,"id=?",new String[]{String.valueOf(id)})==0)return "{}";
                } else {
                    ContentValues v=new ContentValues();v.put("payload","{}");
                    long created=d.insert(table,null,v);if(created<1)return "{}";
                    id=(int)created;obj.put("id",id);
                    ContentValues replace=new ContentValues();replace.put("payload",obj.toString());
                    d.update(table,replace,"id=?",new String[]{String.valueOf(id)});
                }
                return obj.toString();
            } catch(Exception ex){return "{}";}
        }
        synchronized boolean delete(String table,int id){
            if(!"jobs".equals(table)&&!"documents".equals(table)&&!"expenses".equals(table))return false;
            return getWritableDatabase().delete(table,"id=?",new String[]{String.valueOf(id)})>0;
        }
        synchronized boolean restore(String text){
            SQLiteDatabase d=getWritableDatabase();
            d.beginTransaction();
            try {
                JSONObject data=new JSONObject(text);
                JSONArray jobs=data.getJSONArray("records"),docs=data.getJSONArray("documents");
                JSONArray expenses=data.optJSONArray("expenses");if(expenses==null)expenses=new JSONArray();
                JSONObject prefs=data.getJSONObject("settings");
                d.delete("jobs",null,null);d.delete("documents",null,null);d.delete("expenses",null,null);d.delete("settings",null,null);
                importRows(d,"jobs",jobs);importRows(d,"documents",docs);importRows(d,"expenses",expenses);
                ContentValues v=new ContentValues();v.put("k","main");v.put("payload",prefs.toString());
                if(d.insert("settings",null,v)<0)throw new Exception("설정 저장 실패");
                d.setTransactionSuccessful();return true;
            }catch(Exception ex){return false;}finally{d.endTransaction();}
        }
        private void importRows(SQLiteDatabase d,String table,JSONArray list)throws Exception{
            for(int i=0;i<list.length();i++){
                JSONObject row=list.getJSONObject(i);
                ContentValues v=new ContentValues();
                int id=row.isNull("id")?0:row.optInt("id",0);
                if(id>0)v.put("id",id);else row.put("id",(Object)null);
                v.put("payload",row.toString());
                long created=d.insertOrThrow(table,null,v);
                if(id<=0){row.put("id",created);ContentValues replace=new ContentValues();replace.put("payload",row.toString());d.update(table,replace,"id=?",new String[]{String.valueOf(created)});}
            }
        }
    }
}
