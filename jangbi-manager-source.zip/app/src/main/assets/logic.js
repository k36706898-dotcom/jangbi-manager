/* 장비매니저 v0.9 business logic: dependency-free/offline */
(function(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.JangbiLogic = api;
})(typeof window !== 'undefined' ? window : globalThis, function() {
  'use strict';
  const won = n => {
    if (typeof n === 'string') n=n.replace(/[,\s원]/g,'');
    const x=Number(n);
    return Number.isFinite(x) ? Math.max(0, Math.round(x)) : 0;
  };
  const validDate = d => { if(!/^\d{4}-\d{2}-\d{2}$/.test(d||''))return false; const dt=new Date(d+'T00:00:00Z'); return Number.isFinite(dt.getTime()) && dt.toISOString().slice(0,10)===d; };
  const normalizeJob = j => ({...j,id:j.id==null?null:Number(j.id),date:String(j.date||''),company:String(j.company||'').trim(),site:String(j.site||'').trim(),worker:String(j.worker||'').trim(),dispatcher:String(j.dispatcher||'').trim(),machine:String(j.machine||'').trim(),work:String(j.work||'').trim(),amount:won(j.amount),received:Math.min(won(j.amount),won(j.received)),memo:String(j.memo||'').trim()});
  const outstanding = j => Math.max(0,won(j.amount)-won(j.received));
  const status = j => outstanding(j)===0 && won(j.amount)>0 ? '결제완료' : won(j.received)>0 ? '부분결제' : '미결제';
  const sums = jobs => jobs.reduce((a,j)=>{a.count++;a.amount+=won(j.amount);a.received+=won(j.received);a.due+=outstanding(j);return a;},{count:0,amount:0,received:0,due:0});
  const findJobs = (jobs,f={}) => jobs.filter(j => {
    if(f.from&&j.date<f.from||f.to&&j.date>f.to)return false;
    for(const k of ['company','site','worker','dispatcher','machine']) if(f[k] && !String(j[k]||'').toLocaleLowerCase().includes(String(f[k]).trim().toLocaleLowerCase()))return false;
    if(f.payment==='paid' && status(j)!=='결제완료')return false;
    if(f.payment==='unpaid' && outstanding(j)===0)return false;
    if(f.payment==='partial' && status(j)!=='부분결제')return false;
    return true;
  }).sort((a,b)=>b.date.localeCompare(a.date)||Number(b.id||0)-Number(a.id||0));
  const byCompany = jobs => {const map=new Map();for(const j of jobs){const k=j.company||'미지정';if(!map.has(k))map.set(k,[]);map.get(k).push(j);}return [...map].map(([company,entries])=>({company,...sums(entries)})).sort((a,b)=>a.company.localeCompare(b.company,'ko'));};
  const csvCell = v => {let x=String(v??'');if(/^\s*[=+@-]/.test(x)&&!/^\d{4}-\d{2}-\d{2}$/.test(x))x="'"+x;return '"'+x.replace(/"/g,'""')+'"';};
  const csv = jobs => '\ufeff'+[['날짜','거래처','현장명','작업자','배차자','기종','작업내용','청구금액','입금액','미수금','결제상태'],...jobs.map(j=>[j.date,j.company,j.site,j.worker,j.dispatcher,j.machine,j.work,won(j.amount),won(j.received),outstanding(j),status(j)])].map(row=>row.map(csvCell).join(',')).join('\r\n');
  const docLines = jobs => jobs.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(j=>({date:j.date,name:[j.site,j.machine,j.work].filter(Boolean).join(' / ')||'크레인 작업',qty:1,unit:'식',price:won(j.amount)}));
  // '포함' means amounts entered already include VAT, never add VAT twice.
  const docTotals = (lines,vat='included') => {
    const totalLines = (lines||[]).map(x=>Math.max(0,won(x.qty||0))*won(x.price)).reduce((a,b)=>a+b,0);
    if(vat==='extra') {const tax=Math.round(totalLines*0.1);return {supply:totalLines,tax,total:totalLines+tax};}
    if(vat==='included'){const supply=Math.round(totalLines/1.1);return {supply,tax:totalLines-supply,total:totalLines};}
    return {supply:totalLines,tax:0,total:totalLines};
  };
  const normalizeDoc = d=>({...d, type:d.type==='quote'?'quote':'statement',id:d.id==null?null:Number(d.id),docDate:String(d.docDate||''),company:String(d.company||'').trim(),site:String(d.site||''),subject:String(d.subject||''),recipient:String(d.recipient||''),recipientPhone:String(d.recipientPhone||''),notes:String(d.notes||''),validUntil:String(d.validUntil||''),vat:['included','extra','none'].includes(d.vat)?d.vat:'included',lines:Array.isArray(d.lines)?d.lines.map(x=>({date:String(x.date||''),name:String(x.name||'').trim(),qty:won(x.qty),unit:String(x.unit||'식'),price:won(x.price)})):[]});

  // Fuel and repair records are stored separately from sales/work receipts.
  const decimal = (v,places=2) => {
    const n=Number(typeof v==='string'?v.replace(/[,\s]/g,''):v);
    return Number.isFinite(n) && n>=0 ? Math.round(n*10**places)/10**places : 0;
  };
  const normalizeExpense = e => {
    const type=e.type==='maintenance'?'maintenance':'fuel';
    const quantity=decimal(e.quantity);
    const unitPrice=won(e.unitPrice);
    const providedAmount=e.amount!==null&&e.amount!==undefined&&e.amount!=='';
    const amount=providedAmount?won(e.amount):won(quantity*unitPrice);
    return {...e,id:e.id==null?null:Number(e.id),type,date:String(e.date||''),machine:String(e.machine||'').trim(),
      quantity,unitPrice,amount,usageHours:decimal(e.usageHours,1),odometer:decimal(e.odometer,1),
      fuelType:String(e.fuelType||'경유').trim(),station:String(e.station||'').trim(),
      service:String(e.service||'').trim(),vendor:String(e.vendor||'').trim(),
      nextServiceDate:String(e.nextServiceDate||''),memo:String(e.memo||'').trim()};
  };
  const filterExpenses = (entries,filter={}) => entries.filter(e=>
    (!filter.month||e.date.startsWith(filter.month)) &&
    (!filter.type||filter.type==='all'||e.type===filter.type) &&
    (!filter.machine||filter.machine==='all'||e.machine===filter.machine)
  ).sort((a,b)=>b.date.localeCompare(a.date)||Number(b.id||0)-Number(a.id||0));
  const expenseSummary = entries => entries.reduce((a,e)=>{
    if(e.type==='fuel'){a.fuelCount++;a.fuelVolume=Math.round((a.fuelVolume+decimal(e.quantity))*100)/100;a.fuelCost+=won(e.amount);}
    else if(e.type==='maintenance'){a.maintenanceCount++;a.maintenanceCost+=won(e.amount);}
    a.totalCost=a.fuelCost+a.maintenanceCost;return a;
  },{fuelCount:0,fuelVolume:0,fuelCost:0,maintenanceCount:0,maintenanceCost:0,totalCost:0});
  const expenseCsv = entries => '\ufeff'+[
    ['날짜','분류','장비','주유종류','주유량(L)','리터단가(원)','금액(원)','주유소','정비내역','정비업체','사용시간(h)','주행거리(km)','다음정비일','비고'],
    ...entries.map(e=>[e.date,e.type==='fuel'?'주유':'정비',e.machine,e.type==='fuel'?e.fuelType:'',e.type==='fuel'?e.quantity:'',e.type==='fuel'?e.unitPrice:'',e.amount,e.station,e.service,e.vendor,e.usageHours||'',e.odometer||'',e.nextServiceDate,e.memo])
  ].map(row=>row.map(csvCell).join(',')).join('\r\n');
  return {won,validDate,normalizeJob,outstanding,status,sums,findJobs,byCompany,csv,docLines,docTotals,normalizeDoc,normalizeExpense,filterExpenses,expenseSummary,expenseCsv};
});
