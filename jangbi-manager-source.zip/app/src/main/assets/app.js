/* 장비매니저 v0.9 - offline app UI (browser fallback + Android SQLite bridge) */
(() => {
'use strict';
const L=window.JangbiLogic;
const NATIVE=!!(window.AndroidBridge&&typeof window.AndroidBridge.listRecords==='function');
const K={jobs:'jangbi.jobs.v1',settings:'jangbi.settings.v1',docs:'jangbi.documents.v1',expenses:'jangbi.expenses.v1'};
const main=document.getElementById('main');
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const now=iso(new Date());
const ymd=s=>String(s||'').replace(/-/g,'.');
const money=v=>L.won(v).toLocaleString('ko-KR')+'원';
const fmt=v=>L.won(v).toLocaleString('ko-KR');
const parse=(v,def)=>{if(v==null||v==='')return def;try{const value=JSON.parse(v);return value==null?def:value}catch(_){return def}};
const load=(name,def)=>{try{return parse(localStorage.getItem(name),def)}catch(_){return def}};
const store=(name,v)=>{localStorage.setItem(name,JSON.stringify(v));};
const field=(label,id,value='',type='text',attrs='')=>`<div class="field"><label for="${id}">${esc(label)}</label><input id="${id}" type="${type}" value="${esc(value)}" ${attrs}></div>`;
const area=(label,id,value='',attrs='')=>`<div class="field"><label for="${id}">${esc(label)}</label><textarea id="${id}" ${attrs}>${esc(value)}</textarea></div>`;
const select=(label,id,opts,value)=>`<div class="field"><label for="${id}">${esc(label)}</label><select id="${id}">${opts.map(([v,t])=>`<option value="${esc(v)}" ${v===value?'selected':''}>${esc(t)}</option>`).join('')}</select></div>`;
const btn=(txt,action,cls='secondary',extra='')=>`<button type="button" class="btn ${cls}" data-action="${esc(action)}" ${extra}>${esc(txt)}</button>`;
let state={tab:'calendar',month:new Date().getFullYear()*12+new Date().getMonth(),date:null,editing:null,docEditing:null,docType:'statement',docFilter:'all',expenseEditing:null,expenseType:'fuel',expenseMonth:now.slice(0,7),expenseMachine:'all',expenses:[],search:{from:now.slice(0,4)+'-01-01',to:now.slice(0,4)+'-12-31',company:'',site:'',worker:'',dispatcher:'',machine:'',payment:'all'},searchResults:false,settlementMonth:now.slice(0,7),flash:'',jobs:[],docs:[],settings:{}};
function retrieve(){
  const incomingJobs=NATIVE?parse(AndroidBridge.listRecords(),[]):load(K.jobs,[]);
  state.jobs=(Array.isArray(incomingJobs)?incomingJobs:[]).map(L.normalizeJob);
  state.settings=NATIVE?parse(AndroidBridge.getSettings(),{}):load(K.settings,{});
  if(!state.settings||typeof state.settings!=='object'||Array.isArray(state.settings))state.settings={};
  const incomingDocs=NATIVE?parse(AndroidBridge.listDocuments(),[]):load(K.docs,[]);
  state.docs=(Array.isArray(incomingDocs)?incomingDocs:[]).map(L.normalizeDoc);
  const incomingExpenses=NATIVE?parse(AndroidBridge.listExpenses(),[]):load(K.expenses,[]);
  state.expenses=(Array.isArray(incomingExpenses)?incomingExpenses:[]).map(L.normalizeExpense);
  if(!Array.isArray(state.settings.equipment)||!state.settings.equipment.length)state.settings.equipment=['13t / KATO MR-130RF'];
}
function jobSave(raw){const j=L.normalizeJob(raw);if(NATIVE){const r=parse(AndroidBridge.upsertRecord(JSON.stringify(j)),null);if(!r||!r.id)throw Error('저장에 실패했습니다');}else{if(j.id){const ix=state.jobs.findIndex(x=>x.id===j.id);if(ix<0)throw Error('기록이 없습니다');state.jobs[ix]=j;}else{j.id=Math.max(0,...state.jobs.map(x=>x.id||0))+1;state.jobs.push(j);}store(K.jobs,state.jobs);}retrieve();}
function jobRemove(id){if(NATIVE){if(!AndroidBridge.deleteRecord(id))throw Error('삭제 실패');}else{state.jobs=state.jobs.filter(x=>x.id!==id);store(K.jobs,state.jobs);}retrieve();}
function settingsSave(s){if(NATIVE){if(!AndroidBridge.saveSettings(JSON.stringify(s)))throw Error('저장 실패');}else store(K.settings,s);retrieve();}
function docSave(raw){const d=L.normalizeDoc(raw);if(NATIVE){const r=parse(AndroidBridge.upsertDocument(JSON.stringify(d)),null);if(!r||!r.id)throw Error('문서 저장 실패');d.id=r.id;}else{if(d.id){const ix=state.docs.findIndex(x=>x.id===d.id);if(ix<0)throw Error('기존 문서가 없습니다');state.docs[ix]=d;}else{d.id=Math.max(0,...state.docs.map(x=>x.id||0))+1;state.docs.push(d);}store(K.docs,state.docs);}retrieve();return d.id;}
function docRemove(id){if(NATIVE){if(!AndroidBridge.deleteDocument(id))throw Error('삭제 실패');}else{state.docs=state.docs.filter(x=>x.id!==id);store(K.docs,state.docs);}retrieve();}
function go(tab){state.tab=tab;state.date=null;state.editing=null;state.docEditing=null;state.expenseEditing=null;state.flash='';render();window.scrollTo(0,0);}
function toast(s){state.flash=s;render();}
function header(t){return `<h1>${esc(t)}</h1>${state.flash?`<div class="notice">${esc(state.flash)}</div>`:''}`;}
function paymentClass(j){return L.status(j)==='결제완료'?'paid':L.status(j)==='부분결제'?'partial':'';}
function jobCard(j){return `<article class="card"><div class="cardline"><strong>${esc(j.company||'미지정')}</strong><span class="pill ${paymentClass(j)}">${L.status(j)}</span></div><div class="subline">${esc(ymd(j.date))} · ${esc(j.site)} · ${esc(j.machine)}</div><div class="subline">작업자 ${esc(j.worker||'-')} · 배차자 ${esc(j.dispatcher||'-')}</div><div class="cardline" style="margin-top:9px"><strong class="money">${money(j.amount)}</strong><span class="muted">미수 ${money(L.outstanding(j))}</span></div><div class="actions">${btn('수정','edit-job','secondary small',`data-id="${j.id}"`)}${btn('거래명세서','single-statement','secondary small',`data-id="${j.id}"`)}</div></article>`;}
function renderCalendar(){const year=Math.floor(state.month/12),month=state.month%12;const first=new Date(year,month,1);const count=new Date(year,month+1,0).getDate();let days='';for(let i=0;i<first.getDay();i++)days+='<div class="day emptyday"></div>';for(let n=1;n<=count;n++){const date=`${year}-${String(month+1).padStart(2,'0')}-${String(n).padStart(2,'0')}`;const jobs=state.jobs.filter(j=>j.date===date);days+=`<button class="day ${date===now?'today':''}" data-action="day" data-date="${date}"><span class="num">${n}</span>${jobs.slice(0,2).map(j=>`<span class="jobtag ${L.status(j)==='결제완료'?'paid':''}">${esc(j.company)}</span>`).join('')}${jobs.length>2?`<span class="caption">+${jobs.length-2}건</span>`:''}</button>`;}
const monthly=state.jobs.filter(j=>j.date.startsWith(`${year}-${String(month+1).padStart(2,'0')}`));const s=L.sums(monthly);
return `<div class="month-header">${btn('‹','prev-month','secondary')}<h1>${year}년 ${month+1}월</h1>${btn('›','next-month','secondary')}</div><div class="calendar">${['일','월','화','수','목','금','토'].map((x,i)=>`<div class="week ${i===0?'sun':i===6?'sat':''}">${x}</div>`).join('')}${days}</div><div class="tiles" style="margin-top:14px"><div class="tile">이번 달 작업<strong>${s.count}건</strong></div><div class="tile">이번 달 미수금<strong>${money(s.due)}</strong></div></div><p class="muted">날짜를 누르면 작업일지를 등록하거나 확인할 수 있습니다. 날짜 칸에는 업체명을 한 줄로 표시합니다.</p>`;}
function renderDay(){let list=state.jobs.filter(j=>j.date===state.date).sort((a,b)=>b.id-a.id);if(state.editing!==null)return renderJobEditor();return `${header(ymd(state.date)+' 작업일지')}<div class="actions">${btn('‹ 달력으로','back-calendar')}${btn('+ 작업 등록','new-job','fill')}</div>${list.length?list.map(jobCard).join(''):'<div class="empty">등록된 작업이 없습니다.</div>'}`;}
function renderJobEditor(){const j=state.jobs.find(x=>x.id===state.editing)||{date:state.date,company:'',site:'',worker:'',dispatcher:'',machine:state.settings.equipment[0]||'',work:'',amount:0,received:0,memo:''};
return `${header(j.id?'작업일지 수정':'작업일지 등록')}<form id="job-form">${field('작업일 *','job-date',j.date,'date','required')}${field('회사명 / 거래처 *','job-company',j.company,'text','required maxlength="100"')}${field('현장명 *','job-site',j.site,'text','required maxlength="100"')}<div class="form-row">${field('작업자','job-worker',j.worker)}${field('배차자','job-dispatcher',j.dispatcher)}</div>${select('크레인 기종','job-machine',Array.from(new Set([j.machine,...state.settings.equipment].filter(Boolean))).map(s=>[s,s]),j.machine)}${field('작업내용','job-work',j.work)}<div class="form-row">${field('청구금액 (원)','job-amount',j.amount,'number','min="0" step="1" required')}${field('입금액 (원)','job-received',j.received,'number','min="0" step="1" required')}</div>${area('메모','job-memo',j.memo)}<div class="actions"><button class="btn fill" type="submit">저장하기</button>${btn('취소','cancel-job')}${j.id?btn('삭제','delete-job','danger'):''}</div></form>`;}
function renderSearch(){const f=state.search;const rows=L.findJobs(state.jobs,f);return `${header('일지 통합검색')}<form id="search-form"><div class="form-row">${field('시작일','s-from',f.from,'date')}${field('종료일','s-to',f.to,'date')}</div>${field('회사명','s-company',f.company)}${field('현장명','s-site',f.site)}<div class="form-row">${field('작업자','s-worker',f.worker)}${field('배차자','s-dispatcher',f.dispatcher)}</div>${field('기종','s-machine',f.machine)}${select('결제여부','s-payment',[['all','전체'],['paid','결제완료'],['unpaid','미수 있음'],['partial','부분결제']],f.payment)}<button class="btn" type="submit" style="width:100%">검색하기</button></form>${state.searchResults?`<hr><div class="cardline"><h2>검색 결과 ${rows.length}건</h2>${btn('엑셀 CSV 저장','export-search','secondary small')}</div><div class="tiles"><div class="tile">청구 합계<strong>${money(L.sums(rows).amount)}</strong></div><div class="tile">미수 합계<strong>${money(L.sums(rows).due)}</strong></div></div>${rows.length?rows.map(jobCard).join(''):'<div class="empty">검색 결과가 없습니다.</div>'}`:''}`;}
function renderSettlement(){const month=state.settlementMonth;const jobs=state.jobs.filter(j=>j.date.slice(0,7)===month);const groups=L.byCompany(jobs);const sums=L.sums(jobs);return `${header('거래처 정산')}<div class="form-row">${field('정산 월','settlement-month',month,'month')}</div><div class="tiles"><div class="tile">청구 총액<strong>${money(sums.amount)}</strong></div><div class="tile">미수 총액<strong>${money(sums.due)}</strong></div></div><div class="actions">${btn('이달 내역 CSV 저장','export-month','secondary fill')}</div>${groups.length?groups.map(g=>`<article class="card"><div class="cardline"><strong>${esc(g.company)}</strong><span class="pill">${g.count}건</span></div><div class="subline">청구 ${money(g.amount)} · 입금 ${money(g.received)}</div><p class="money bad" style="margin:8px 0">미수 ${money(g.due)}</p>${btn('거래명세서 만들기','statement-month','secondary small',`data-company="${esc(g.company)}"`)}</article>`).join(''):'<div class="empty">선택한 달의 작업 내역이 없습니다.</div>'}`;}
function docName(d){return d.type==='quote'?'견적서':'거래명세서';}
function renderDocuments(){let docs=state.docs.filter(d=>state.docFilter==='all'||d.type===state.docFilter).sort((a,b)=>b.docDate.localeCompare(a.docDate)||b.id-a.id);
return `${header('문서 관리')}<div class="actions">${btn('+ 거래명세서','new-statement','fill')}${btn('+ 견적서','new-quote','fill')}</div><div class="tabs">${[['all','전체'],['statement','거래명세서'],['quote','견적서']].map(([k,v])=>`<button data-action="doc-filter" data-filter="${k}" class="${state.docFilter===k?'selected':''}">${v}</button>`).join('')}</div><div class="notice">거래명세서는 작업일지에서 불러올 수 있고, 견적서는 작업 전 미리 작성할 수 있습니다. PDF는 문서 미리보기에서 인쇄 → PDF로 저장을 선택하세요.</div>${docs.length?docs.map(d=>{const t=L.docTotals(d.lines,d.vat);return `<article class="card"><div class="cardline"><strong>${esc(docName(d))} · ${esc(d.company)}</strong><span class="pill">${esc(ymd(d.docDate))}</span></div><div class="subline">${esc(d.subject||d.site||'-')} · ${d.lines.length}항목</div><p class="money" style="margin:10px 0">${money(t.total)}</p><div class="actions">${btn('열기·수정','edit-document','secondary small',`data-id="${d.id}"`)}${btn('인쇄/PDF','print-document','secondary small',`data-id="${d.id}"`)}${btn('삭제','remove-document','danger small',`data-id="${d.id}"`)}</div></article>`;}).join(''):'<div class="empty">저장된 문서가 없습니다.</div>'}`;}
function newDoc(type,jobs=[],company=''){state.docType=type;state.docEditing={type,id:null,docDate:now,company:company||(jobs[0]?.company||''),site:jobs[0]?.site||'',subject:type==='quote'?'크레인 작업 견적':'크레인 작업 거래명세',recipient:'',recipientPhone:'',notes:'',vat:'included',validUntil:'',lines:jobs.length?L.docLines(jobs):[{date:now,name:type==='quote'?'크레인 작업':'',qty:1,unit:'식',price:0}]};state.tab='documents';render();}
function renderDocEdit(){const d=state.docEditing;let sum=L.docTotals(d.lines,d.vat);return `${header(d.id?docName(d)+' 수정':docName(d)+' 작성')}<div class="notice">부가세 '포함'은 입력한 금액 안에 부가세가 포함된 것으로 계산합니다. 실제 계약 조건에 맞게 선택하세요.</div><form id="doc-form">${field('작성일','d-date',d.docDate,'date','required')}${field('받는 업체 / 거래처 *','d-company',d.company,'text','required')}${field('현장명','d-site',d.site)}${field('문서 제목','d-subject',d.subject)}<div class="form-row">${field('받는 분','d-recipient',d.recipient)}${field('연락처','d-phone',d.recipientPhone)}</div>${d.type==='quote'?field('견적 유효기간','d-valid',d.validUntil,'date'):''}${select('부가세 처리','d-vat',[['included','포함 (총액 유지)'],['extra','별도 (10% 추가)'],['none','부가세 없음']],d.vat)}<h2>작업 / 품목 내역</h2><div class="caption" style="margin-bottom:8px">항목명 / 수량 / 단위 / 단가(원)</div>${d.lines.map((r,i)=>`<div class="line-row"> <input aria-label="품목 ${i+1}" data-line="${i}" data-key="name" value="${esc(r.name)}" placeholder="작업내용"><input aria-label="수량" type="number" data-line="${i}" data-key="qty" value="${r.qty}" min="0"><input aria-label="단위" data-line="${i}" data-key="unit" value="${esc(r.unit)}"><input aria-label="단가" type="number" data-line="${i}" data-key="price" value="${r.price}" min="0"><button type="button" data-action="remove-line" data-index="${i}" aria-label="항목 삭제">×</button></div>`).join('')}${btn('+ 항목 추가','add-line','secondary small')}<div class="card"><div class="sumrow"><span>공급가액</span><b id="d-supply">${money(sum.supply)}</b></div><div class="sumrow"><span>부가세</span><b id="d-tax">${money(sum.tax)}</b></div><div class="sumrow"><span>합계금액</span><b id="d-total">${money(sum.total)}</b></div></div>${area('비고 / 결제조건 / 안내사항','d-notes',d.notes)}<div class="actions"><button class="btn fill" type="submit">문서 저장</button>${btn('미리보기·PDF','preview-draft','secondary fill')}${btn('취소','cancel-document')}</div></form>`;}
function lineInputs(){if(!state.docEditing)return;const d=state.docEditing;for(const el of document.querySelectorAll('[data-line][data-key]')){const i=Number(el.dataset.line);if(d.lines[i])d.lines[i][el.dataset.key]=el.value;}const vat=$('d-vat');if(vat)d.vat=vat.value;}
function docFields(){const d=state.docEditing;if(!d)return;for(const [k,id] of Object.entries({docDate:'d-date',company:'d-company',site:'d-site',subject:'d-subject',recipient:'d-recipient',recipientPhone:'d-phone',notes:'d-notes',validUntil:'d-valid',vat:'d-vat'}))if($(id))d[k]=$(id).value;lineInputs();d.lines=d.lines.map(x=>({date:x.date||'',name:String(x.name||'').trim(),qty:L.won(x.qty),unit:String(x.unit||'식'),price:L.won(x.price)}));}

// Each fuel / maintenance record belongs to a registered equipment item.
function expenseSave(raw){
  const e=L.normalizeExpense(raw);
  if(NATIVE){const result=parse(AndroidBridge.upsertExpense(JSON.stringify(e)),null);if(!result||!result.id)throw Error('장비관리 일지 저장 실패');}
  else {if(e.id){const i=state.expenses.findIndex(x=>x.id===e.id);if(i<0)throw Error('수정할 기록이 없습니다');state.expenses[i]=e;}
        else {e.id=Math.max(0,...state.expenses.map(x=>x.id||0))+1;state.expenses.push(e);}store(K.expenses,state.expenses);}
  retrieve();
}
function expenseRemove(id){
  if(NATIVE){if(!AndroidBridge.deleteExpense(id))throw Error('일지 삭제 실패');}
  else {state.expenses=state.expenses.filter(x=>x.id!==id);store(K.expenses,state.expenses);}
  retrieve();
}
function startExpense(type,id=null){
  state.expenseEditing=id!=null?JSON.parse(JSON.stringify(state.expenses.find(e=>e.id===id))):{
    id:null,type,date:now,machine:state.settings.equipment[0]||'',quantity:0,unitPrice:0,amount:0,
    usageHours:0,odometer:0,fuelType:'경유',station:'',service:'',vendor:'',nextServiceDate:'',memo:''
  };
  if(!state.expenseEditing)return;
  state.expenseType=state.expenseEditing.type;state.tab='equipment';render();
}
function renderExpenseEditor(){const e=state.expenseEditing;
  const isFuel=e.type==='fuel';
  const devices=[...new Set([e.machine,...state.settings.equipment].filter(Boolean))];
  return `${header((isFuel?'주유일지':'정비일지')+(e.id?' 수정':' 등록'))}
    <div class="notice">장비에 사용한 비용을 기록합니다. 작업 매출이나 미수금과 별도로 관리됩니다.</div>
    <form id="expense-form">${field('날짜 *','e-date',e.date,'date','required')}
    ${select('장비 / 기종 *','e-machine',devices.map(m=>[m,m]),e.machine)}
    ${isFuel?`${select('연료 종류','e-fuel-type',[['경유','경유'],['휘발유','휘발유'],['요소수','요소수'],['기타','기타']],e.fuelType)}
      <div class="form-row">${field('주유량 (L) *','e-quantity',e.quantity,'number','min="0.01" step="0.01" required')}
      ${field('리터 단가 (원)','e-unit-price',e.unitPrice,'number','min="0" step="1"')}</div>
      ${field('주유소 / 장소','e-station',e.station)}`:
      `${field('정비 / 수리 내용 *','e-service',e.service,'text','required placeholder="예: 유압오일 교체"')}
      ${field('정비업체','e-vendor',e.vendor)}${field('다음 정비 예정일 (선택)','e-next',e.nextServiceDate,'date')}`}
    ${field(isFuel?'주유금액 (원) *':'정비비용 (원) *','e-amount',e.amount,'number','min="0" step="1" required')}
    <div class="form-row">${field('장비 사용시간 (h)','e-hours',e.usageHours,'number','min="0" step="0.1"')}
      ${field('주행거리 (km)','e-odometer',e.odometer,'number','min="0" step="0.1"')}</div>
    ${area('메모','e-memo',e.memo)}
    <div class="actions"><button type="submit" class="btn fill">저장하기</button>${btn('취소','cancel-expense')}${e.id?btn('삭제','delete-expense','danger'):''}</div></form>`;
}
function renderEquipment(){if(state.expenseEditing)return renderExpenseEditor();
  const filtered=L.filterExpenses(state.expenses,{type:state.expenseType,month:state.expenseMonth,machine:state.expenseMachine});
  const monthRows=L.filterExpenses(state.expenses,{month:state.expenseMonth,machine:state.expenseMachine});
  const sum=L.expenseSummary(monthRows);
  const machines=[['all','전체 장비'],...state.settings.equipment.map(m=>[m,m])];
  return `${header('장비관리')}<div class="tabs">
    ${[['fuel','주유일지'],['maintenance','정비일지']].map(([key,label])=>`<button data-action="expense-tab" data-type="${key}" class="${state.expenseType===key?'selected':''}">${label}</button>`).join('')}</div>
    <div class="form-row">${field('조회 월','expense-month',state.expenseMonth,'month')}${select('장비별 조회','expense-machine',machines,state.expenseMachine)}</div>
    <div class="tiles"><div class="tile">주유 ${sum.fuelCount}회 · ${sum.fuelVolume.toLocaleString('ko-KR')} L<strong>${money(sum.fuelCost)}</strong></div>
    <div class="tile">정비 ${sum.maintenanceCount}건<strong>${money(sum.maintenanceCost)}</strong></div></div>
    <div class="cardline" style="margin-top:12px"><strong>월 장비 유지비 합계</strong><strong class="money">${money(sum.totalCost)}</strong></div>
    <div class="actions">${btn(state.expenseType==='fuel'?'+ 주유 등록':'+ 정비 등록','new-expense','fill')}${btn('이달 기록 CSV 저장','export-expenses','secondary')}</div>
    ${filtered.length?filtered.map(e=>`<article class="card">
      <div class="cardline"><strong>${esc(e.type==='fuel'?`${e.quantity}L · ${e.fuelType}`:e.service)}</strong><b class="money">${money(e.amount)}</b></div>
      <div class="subline">${esc(ymd(e.date))} · ${esc(e.machine)}</div>
      <div class="subline">${esc(e.type==='fuel'?(e.station||'주유소 미입력'):(e.vendor||'정비업체 미입력'))}
       ${e.type==='fuel'&&e.unitPrice?' · '+fmt(e.unitPrice)+'원/L':''}</div>
      ${e.memo?`<div class="subline">메모: ${esc(e.memo)}</div>`:''}
      ${e.type==='maintenance'&&e.nextServiceDate?`<div class="subline">다음 정비: ${esc(ymd(e.nextServiceDate))}</div>`:''}
      <div class="actions">${btn('수정','edit-expense','secondary small',`data-id="${e.id}"`)}${btn('삭제','remove-expense','danger small',`data-id="${e.id}"`)}</div></article>`).join(''):'<div class="empty">선택한 월의 기록이 없습니다.</div>'}`;
}

function renderSettings(){const s=state.settings;return `${header('환경설정')}<div class="notice">최초 사용 시 상호명과 장비를 등록하세요. 이 정보는 견적서와 거래명세서에도 자동으로 들어갑니다.</div><form id="settings-form">${field('내 상호명 *','my-company',s.company||'','text','required')}${field('대표자명','my-owner',s.owner||'')}${field('전화번호','my-phone',s.phone||'','tel')}${field('사업자등록번호','my-business',s.businessNo||'')}${field('사업장 주소','my-address',s.address||'')}${field('이메일','my-email',s.email||'','email')}${field('입금 계좌','my-bank',s.bank||'')}${area('보유 장비 / 기종 (한 줄에 한 대)','my-equipment',s.equipment.join('\n'),'rows="4"')}<button class="btn" style="width:100%" type="submit">내 정보 저장</button></form><hr><h2>데이터 백업 및 복원</h2><p class="muted">백업은 작업일지, 견적서, 거래명세서, 주유일지, 정비일지, 환경설정 전체를 포함합니다. 기기 분실에 대비하여 별도 보관하세요.</p><div class="actions">${btn('전체 데이터 백업 (.json)','backup','secondary fill')}<label class="btn secondary fill" for="import-file" style="text-align:center">백업파일 복원</label><input type="file" id="import-file" accept="application/json,.json" hidden></div><p class="muted">복원 시 기존 저장 내용이 모두 교체됩니다. 복원 전에 먼저 백업하세요.</p>`;}
function printDocument(d){
  const totals=L.docTotals(d.lines,d.vat),me=state.settings;
  const lineRows=d.lines.map((r,i)=>`<tr><td class="center">${i+1}</td><td class="center">${esc(ymd(r.date||''))}</td><td>${esc(r.name)}</td><td class="right">${fmt(r.qty)}</td><td class="center">${esc(r.unit)}</td><td class="right">${fmt(r.price)}</td><td class="right">${fmt(L.won(r.qty)*L.won(r.price))}</td></tr>`).join('');
  $('print-page').innerHTML=`<div class="print-doc"><h1>${docName(d)}</h1><div class="print-meta"><div><p><strong>발행일 :</strong> ${esc(ymd(d.docDate))}</p><p><strong>받는 곳 :</strong> ${esc(d.company)}</p><p><strong>담당 :</strong> ${esc(d.recipient||'-')} ${esc(d.recipientPhone)}</p><p><strong>현장 :</strong> ${esc(d.site||'-')}</p>${d.type==='quote'?`<p><strong>유효기간 :</strong> ${esc(ymd(d.validUntil)||'-')}</p>`:''}</div><div><p><strong>공급자 :</strong> ${esc(me.company||'미등록')}</p><p><strong>대표 :</strong> ${esc(me.owner||'-')}</p><p><strong>사업자번호 :</strong> ${esc(me.businessNo||'-')}</p><p><strong>전화 :</strong> ${esc(me.phone||'-')}</p><p><strong>주소 :</strong> ${esc(me.address||'-')}</p></div></div><p><strong>${esc(d.subject)}</strong></p><table><colgroup><col style="width:5%"><col style="width:15%"><col style="width:33%"><col style="width:8%"><col style="width:7%"><col style="width:14%"><col style="width:18%"></colgroup><thead><tr><th>번호</th><th>작업일</th><th>품목 / 작업 내용</th><th>수량</th><th>단위</th><th>단가</th><th>금액</th></tr></thead><tbody>${lineRows||'<tr><td colspan="7">항목 없음</td></tr>'}</tbody></table><div style="margin:15px 0 0 auto;max-width:270px"><div class="sumrow"><span>공급가액</span><b>${money(totals.supply)}</b></div><div class="sumrow"><span>부가세 (${d.vat==='included'?'포함':d.vat==='extra'?'별도':'없음'})</span><b>${money(totals.tax)}</b></div><div class="sumrow"><span>합계금액</span><b>${money(totals.total)}</b></div></div><div class="print-notes"><strong>비고</strong>\n${esc(d.notes||'')}</div>${me.bank?`<p>입금계좌 : ${esc(me.bank)}</p>`:''}<p style="text-align:center;margin-top:24mm;font-size:12px">${esc(me.company||'')} ${esc(me.owner||'')} (인)</p></div>`;
  if(NATIVE){AndroidBridge.printCurrentPage(docName(d)+'_'+d.company);}else{window.print();}
}
function backupFile(name,mime,text){if(NATIVE)AndroidBridge.exportFile(name,mime,text);else{const b=new Blob([text],{type:mime}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);}}
function restoreBackup(raw){let o=parse(raw,null);if(!o||o.kind!=='JANGBI_MANAGER_BACKUP'||![1,2,3].includes(o.schemaVersion)||!Array.isArray(o.records)||typeof o.settings!=='object'||o.settings===null||o.records.length>100000||o.documents?.length>100000||o.expenses?.length>100000||(o.documents!=null&&!Array.isArray(o.documents)||o.expenses!=null&&!Array.isArray(o.expenses)))throw Error('지원하지 않는 백업 파일입니다');
const jobs=o.records.map(L.normalizeJob),docs=(o.documents||[]).map(L.normalizeDoc),expenses=(o.expenses||[]).map(L.normalizeExpense);for(const j of jobs)if(!L.validDate(j.date)||!j.company||!j.site)throw Error('백업에 잘못된 작업 기록이 있습니다');for(const d of docs)if(!L.validDate(d.docDate)||!d.company||!d.lines.length)throw Error('백업에 잘못된 문서가 있습니다');
for(const e of expenses)if(!L.validDate(e.date)||!e.machine||(e.type==='fuel'&&e.quantity<=0)||(e.type==='maintenance'&&!e.service)||e.nextServiceDate&&!L.validDate(e.nextServiceDate))throw Error('백업에 잘못된 장비관리 기록이 있습니다');
if(!confirm(`기존 작업 ${state.jobs.length}건, 문서 ${state.docs.length}건, 장비관리 ${state.expenses.length}건을 모두 교체하고 복원할까요?`))return;
if(NATIVE){if(!AndroidBridge.restoreBackup(JSON.stringify({records:jobs,documents:docs,expenses,settings:o.settings})))throw Error('복원 실패');}else{store(K.jobs,jobs);store(K.docs,docs);store(K.expenses,expenses);store(K.settings,o.settings);}retrieve();go('calendar');toast('백업 복원 완료');}
function render(){
  document.querySelectorAll('[data-nav]').forEach(n=>{n.classList.toggle('active',n.dataset.nav===state.tab);n.setAttribute('aria-current',n.dataset.nav===state.tab?'page':'false');});
  main.innerHTML=state.tab==='calendar'?(state.date?renderDay():renderCalendar()):state.tab==='search'?renderSearch():state.tab==='settlement'?renderSettlement():state.tab==='documents'?(state.docEditing?renderDocEdit():renderDocuments()):state.tab==='equipment'?renderEquipment():renderSettings();
}
function runAction(el){const a=el.dataset.action,id=Number(el.dataset.id);
  if(a==='prev-month')state.month--,render();
  else if(a==='next-month')state.month++,render();
  else if(a==='day')state.date=el.dataset.date,state.editing=null,render();
  else if(a==='back-calendar')state.date=null,state.editing=null,render();
  else if(a==='new-job')state.editing=0,render();
  else if(a==='edit-job'){const job=state.jobs.find(j=>j.id===id);if(!job)return;state.date=job.date;state.editing=id;state.tab='calendar';render();}
  else if(a==='cancel-job')state.editing=null,render();
  else if(a==='delete-job'){if(!confirm('이 작업일지를 삭제할까요?'))return;try{jobRemove(state.editing);state.editing=null;toast('작업일지를 삭제했습니다');}catch(e){alert(e.message);}}
  else if(a==='export-search')backupFile('작업일지_검색결과.csv','text/csv;charset=utf-8',L.csv(L.findJobs(state.jobs,state.search)));
  else if(a==='export-month')backupFile('거래처정산_'+state.settlementMonth+'.csv','text/csv;charset=utf-8',L.csv(state.jobs.filter(j=>j.date.slice(0,7)===state.settlementMonth)));
  else if(a==='statement-month'){const comp=el.dataset.company,js=state.jobs.filter(j=>j.company===comp&&j.date.slice(0,7)===state.settlementMonth);newDoc('statement',js,comp);}
  else if(a==='single-statement'){const j=state.jobs.find(x=>x.id===id);if(j)newDoc('statement',[j],j.company);}
  else if(a==='new-statement')newDoc('statement');
  else if(a==='new-quote')newDoc('quote');
  else if(a==='doc-filter'){state.docFilter=el.dataset.filter;render();}
  else if(a==='edit-document'){const d=state.docs.find(x=>x.id===id);if(d)state.docEditing=JSON.parse(JSON.stringify(d)),render();}
  else if(a==='cancel-document')state.docEditing=null,render();
  else if(a==='add-line'){docFields();state.docEditing.lines.push({date:now,name:'',qty:1,unit:'식',price:0});render();}
  else if(a==='remove-line'){docFields();if(state.docEditing.lines.length<=1){alert('최소 한 항목이 필요합니다');return;}state.docEditing.lines.splice(Number(el.dataset.index),1);render();}
  else if(a==='preview-draft'){docFields();if(!state.docEditing.company||!L.validDate(state.docEditing.docDate)){alert('작성일과 거래처를 입력해주세요');return;}printDocument(state.docEditing);}
  else if(a==='print-document'){const d=state.docs.find(x=>x.id===id);if(d)printDocument(d);}
  else if(a==='remove-document'){if(!confirm('이 문서를 삭제할까요?'))return;try{docRemove(id);toast('문서를 삭제했습니다');}catch(e){alert(e.message);}}
  else if(a==='expense-tab'){state.expenseType=el.dataset.type;state.expenseEditing=null;render();}
  else if(a==='new-expense')startExpense(state.expenseType);
  else if(a==='edit-expense')startExpense(state.expenseType,id);
  else if(a==='cancel-expense'){state.expenseEditing=null;render();}
  else if(a==='remove-expense'||a==='delete-expense'){
    const toDelete=a==='delete-expense'?state.expenseEditing?.id:id;
    if(!toDelete||!confirm('이 장비관리 기록을 삭제할까요?'))return;
    try{expenseRemove(toDelete);state.expenseEditing=null;toast('장비관리 기록을 삭제했습니다');}catch(err){alert(err.message);}
  }
  else if(a==='export-expenses'){
    const rows=L.filterExpenses(state.expenses,{month:state.expenseMonth,machine:state.expenseMachine});
    backupFile('장비관리_'+state.expenseMonth+'.csv','text/csv;charset=utf-8',L.expenseCsv(rows));
  }
  else if(a==='backup'){const data={kind:'JANGBI_MANAGER_BACKUP',schemaVersion:3,exportedAt:new Date().toISOString(),records:state.jobs,documents:state.docs,expenses:state.expenses,settings:state.settings};backupFile('장비매니저_전체백업_'+now+'.json','application/json',JSON.stringify(data,null,2));}
}
main.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(el)runAction(el);});
main.addEventListener('input',e=>{
  if(state.expenseEditing?.type==='fuel'&&e.target.matches('#e-quantity,#e-unit-price')){
    const qty=Number($('e-quantity')?.value||0),price=Number($('e-unit-price')?.value||0);
    if(Number.isFinite(qty)&&Number.isFinite(price)&&qty>=0&&price>=0)$('e-amount').value=String(Math.round(qty*price));
  }
  if(state.docEditing&&e.target.matches('[data-line],#d-vat')){lineInputs();const t=L.docTotals(state.docEditing.lines,state.docEditing.vat);$('d-supply').textContent=money(t.supply);$('d-tax').textContent=money(t.tax);$('d-total').textContent=money(t.total);}});
main.addEventListener('change',e=>{if(e.target.id==='settlement-month'){state.settlementMonth=e.target.value;render();}if(e.target.id==='expense-month'){state.expenseMonth=e.target.value;render();}if(e.target.id==='expense-machine'){state.expenseMachine=e.target.value;render();}if(e.target.id==='import-file'){const f=e.target.files?.[0];if(!f)return;f.text().then(restoreBackup).catch(err=>alert('백업 복원 오류: '+err.message));}});
main.addEventListener('submit',e=>{e.preventDefault();const f=e.target;
  if(f.id==='job-form'){
    const j={id:state.editing||null,date:$('job-date').value,company:$('job-company').value,site:$('job-site').value,worker:$('job-worker').value,dispatcher:$('job-dispatcher').value,machine:$('job-machine').value,work:$('job-work').value,amount:$('job-amount').value,received:$('job-received').value,memo:$('job-memo').value};
    if(!L.validDate(j.date)||!j.company.trim()||!j.site.trim())return alert('날짜, 거래처, 현장명을 확인하세요');if(!/^\d+$/.test(j.amount)||!/^\d+$/.test(j.received)||Number(j.received)>Number(j.amount))return alert('청구금액과 입금액을 확인하세요');try{jobSave(j);state.date=j.date;state.editing=null;toast('작업일지를 저장했습니다');}catch(err){alert(err.message);}
  }else if(f.id==='search-form'){
    for(const k of ['from','to','company','site','worker','dispatcher','machine','payment'])state.search[k]=$('s-'+k).value.trim();if(state.search.from>state.search.to)return alert('검색 시작일이 종료일 이후입니다');state.searchResults=true;render();
  }else if(f.id==='settings-form'){
    const s={company:$('my-company').value.trim(),owner:$('my-owner').value.trim(),phone:$('my-phone').value.trim(),businessNo:$('my-business').value.trim(),address:$('my-address').value.trim(),email:$('my-email').value.trim(),bank:$('my-bank').value.trim(),equipment:[...new Set($('my-equipment').value.split('\n').map(x=>x.trim()).filter(Boolean))]};if(!s.company||!s.equipment.length)return alert('상호명과 장비를 입력해주세요');try{settingsSave(s);go('calendar');toast('환경설정을 저장했습니다');}catch(err){alert(err.message);}
  }else if(f.id==='expense-form'){
    const raw={id:state.expenseEditing?.id||null,type:state.expenseEditing?.type||state.expenseType,
      date:$('e-date').value,machine:$('e-machine').value,amount:$('e-amount').value,
      usageHours:$('e-hours').value,odometer:$('e-odometer').value,memo:$('e-memo').value,
      quantity:$('e-quantity')?.value||0,unitPrice:$('e-unit-price')?.value||0,
      fuelType:$('e-fuel-type')?.value||'경유',station:$('e-station')?.value||'',
      service:$('e-service')?.value||'',vendor:$('e-vendor')?.value||'',nextServiceDate:$('e-next')?.value||''};
    if(!L.validDate(raw.date)||!raw.machine)return alert('작업 날짜와 장비를 확인하세요');
    if(raw.type==='fuel'&&!(Number(raw.quantity)>0))return alert('주유량은 0보다 커야 합니다');
    if(raw.type==='maintenance'&&!raw.service.trim())return alert('정비 내용을 입력해주세요');
    if(raw.nextServiceDate&&!L.validDate(raw.nextServiceDate))return alert('다음 정비 예정일을 확인해주세요');
    for(const k of ['amount','usageHours','odometer','quantity','unitPrice'])if(!Number.isFinite(Number(raw[k]))||Number(raw[k])<0)return alert('수량과 금액은 0 이상의 숫자로 입력해주세요');
    if(!/^\d+$/.test(raw.amount))return alert('비용은 0 이상의 정수로 입력해주세요');
    try{expenseSave(raw);state.expenseEditing=null;toast('장비관리 일지를 저장했습니다');}catch(err){alert(err.message);}
  }else if(f.id==='doc-form'){
    docFields();const d=state.docEditing;if(!L.validDate(d.docDate)||!d.company||d.lines.some(x=>!x.name||x.qty<=0))return alert('작성일, 거래처, 모든 품목명과 수량을 입력하세요');try{docSave(d);state.docEditing=null;toast('문서를 저장했습니다');}catch(err){alert(err.message);}
  }
});
$('bottom').addEventListener('click',e=>{let b=e.target.closest('[data-nav]');if(b)go(b.dataset.nav);});$('gear').addEventListener('click',()=>go('settings'));
retrieve();if(!state.settings.company)state.tab='settings';render();
})();
