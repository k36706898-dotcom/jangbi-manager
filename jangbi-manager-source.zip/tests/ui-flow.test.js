const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const assets=path.join(__dirname,'../app/src/main/assets');
const content={ 'jangbi.settings.v1':JSON.stringify({company:'올림중기',equipment:['13t / KATO MR-130RF']}) };
const localStorage={getItem:k=>content[k]??null,setItem:(k,v)=>{content[k]=v;}};
const listeners={};
const main={innerHTML:'',addEventListener(name,fn){listeners[name]=fn;}};
const controls={};
const field=id=>controls[id] ||= {value:'',textContent:'',addEventListener(){}};
const bottom={addEventListener(name,fn){listeners['nav-'+name]=fn;}};
const gear={addEventListener(name,fn){listeners['gear-'+name]=fn;}};
const pagePrint={innerHTML:''};
const navKeys=['calendar','search','settlement','documents','equipment'];
const navButtons=navKeys.map(nav=>({dataset:{nav},classList:{toggle(){}},setAttribute(){}}));
const document={getElementById(id){return id==='main'?main:id==='bottom'?bottom:id==='gear'?gear:id==='print-page'?pagePrint:field(id);},querySelectorAll(sel){if(sel==='[data-nav]')return navButtons;return [];}};
const sandbox={window:{scrollTo(){}},document,localStorage,console,alert(msg){throw new Error(msg)},confirm(){return true},setTimeout(){},Blob,URL,Date,Intl,Number,String,Math};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(assets,'logic.js'),'utf8'),sandbox);
vm.runInContext(fs.readFileSync(path.join(assets,'app.js'),'utf8'),sandbox);
function nav(which){listeners['nav-click']({target:{closest(){return {dataset:{nav:which}};}}});}
function click(action,dataset={}){listeners.click({target:{closest(){return {dataset:{action,...dataset}};}}});}
function input(id,value){field(id).value=value;listeners.input({target:{matches:q=>q.split(',').includes('#'+id)}});}
function submit(form){listeners.submit({preventDefault(){},target:{id:form}});}
nav('equipment');assert.match(main.innerHTML,/주유일지/);
click('new-expense');assert.match(main.innerHTML,/주유량/);
input('e-date',new Date().toISOString().slice(0,10));input('e-machine','13t / KATO MR-130RF');
input('e-quantity','25.5');input('e-unit-price','1600');assert.equal(field('e-amount').value,'40800');
input('e-station','주유소');input('e-hours','123.5');input('e-odometer','0');input('e-memo','테스트');input('e-fuel-type','경유');submit('expense-form');
let expenses=JSON.parse(content['jangbi.expenses.v1']);assert.equal(expenses.length,1);assert.equal(expenses[0].amount,40800);assert.match(main.innerHTML,/40,800원/);
click('expense-tab',{type:'maintenance'});click('new-expense');
input('e-date',new Date().toISOString().slice(0,10));input('e-machine','13t / KATO MR-130RF');
input('e-service','유압오일 교환');input('e-vendor','정비소');input('e-next','2027-01-01');input('e-amount','230000');input('e-hours','128');input('e-odometer','0');input('e-memo','교환 완료');submit('expense-form');
expenses=JSON.parse(content['jangbi.expenses.v1']);assert.equal(expenses.length,2);assert.equal(expenses[1].service,'유압오일 교환');assert.match(main.innerHTML,/270,800원/);
click('edit-expense',{id:'2'});assert.match(main.innerHTML,/정비일지 수정/);
input('e-amount','200000');submit('expense-form');expenses=JSON.parse(content['jangbi.expenses.v1']);assert.equal(expenses[1].amount,200000);assert.match(main.innerHTML,/240,800원/);
click('expense-tab',{type:'fuel'});assert.match(main.innerHTML,/주유소/);
click('remove-expense',{id:'1'});expenses=JSON.parse(content['jangbi.expenses.v1']);assert.equal(expenses.length,1);
console.log('PASS: UI event-flow test (fuel auto amount/save, maintenance save/edit, monthly totals, tab switch, delete)');
