// Offline source validation; does not replace an Android APK build.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const file=p=>fs.readFileSync(path.join(root,p));
const androidManifest=file('app/src/main/AndroidManifest.xml').toString();
const java=file('app/src/main/java/com/ollim/jangbimanager/MainActivity.java').toString();
const app=file('app/src/main/assets/app.js').toString();
const html=file('app/src/main/assets/index.html').toString();
const style=file('app/src/main/assets/styles.css').toString();
const gradle=file('app/build.gradle').toString();
const workflow=file('.github/workflows/build-apk.yml').toString();
assert.match(androidManifest,/android:icon="@mipmap\/ic_launcher"/);
assert.match(androidManifest,/android:name="\.MainActivity"/);
assert.match(androidManifest,/LAUNCHER/);
assert.match(gradle,/compileSdk 35/);
assert.match(gradle,/targetSdk 34/);
assert.match(html,/장비매니저/);
assert.match(style,/@media print/);
assert.match(app,/주유일지/);
assert.match(app,/정비일지/);
assert.match(app,/견적서/);
assert.match(app,/거래명세서/);
assert.match(workflow,/assembleDebug/);
const calls=[...app.matchAll(/\bAndroidBridge\.([a-zA-Z_$][\w$]*)\s*\(/g)].map(m=>m[1]);
for(const method of new Set(calls))assert.match(java,new RegExp('public\\s+\\w+\\s+'+method+'\\s*\\('),'Missing Java bridge method '+method);
for(const size of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']){
 for(const name of ['ic_launcher.png','ic_launcher_round.png']){
  const b=file(`app/src/main/res/mipmap-${size}/${name}`);
  assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
  assert(b.length>1000);
 }
}
const icon=file('app/src/main/assets/icon.png');assert.equal(icon.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
for(const a of ['logic.js','app.js','styles.css','icon.png'])assert(file('app/src/main/assets/'+a).length>0);
console.log('PASS: app sources, Android bridge methods ('+new Set(calls).size+'), icons, resources and CI build config');
